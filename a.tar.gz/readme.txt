"kinect2"  computer vision development
ring recognize and judge
